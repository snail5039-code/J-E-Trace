package com.jetrace.backend.studentDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentTaskSubmitRequest {
    private String loginId;
    private String content;
    private Boolean aiUsed;
}