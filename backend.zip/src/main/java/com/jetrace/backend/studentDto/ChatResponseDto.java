package com.jetrace.backend.studentDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatResponseDto {
    private boolean relevant;
    private int score;
    private String answer;
    private String status;
}