package com.jetrace.backend.studentDto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentTaskLogResponse {
    private Long id;
    private Long taskId;
    private String studentName;
    private String question;
    private String answer;
    private LocalDateTime createdAt;
    private String status;
}